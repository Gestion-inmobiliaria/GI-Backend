export enum MONTH {
    JANUARY = 'enero',
    FEBRUARY = 'febrero',
    MARCH = 'marzo',
    APRIL = 'abril',
    MAY = 'mayo',
    JUNE = 'junio',
    JULY = 'julio',
    AUGUST = 'agosto',
    SEPTEMBER = 'septiembre',
    OCTOBER = 'octubre',
    NOVEMBER = 'noviembre',
    DECEMBER = 'diciembre',
  }
  
  export const months = [
    MONTH.JANUARY,
    MONTH.FEBRUARY,
    MONTH.MARCH,
    MONTH.APRIL,
    MONTH.MAY,
    MONTH.JUNE,
    MONTH.JULY,
    MONTH.AUGUST,
    MONTH.SEPTEMBER,
    MONTH.OCTOBER,
    MONTH.NOVEMBER,
    MONTH.DECEMBER
  ]