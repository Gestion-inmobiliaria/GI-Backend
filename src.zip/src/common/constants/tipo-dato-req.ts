export enum TIPO_DATO_REQ {
    BODY = 'body',
    QUERY = 'query',
    PARAMS = 'params',
    HEADERS = 'headers',
}

export const TIPO_DATOS_REQ_KEY = 'tipo-datos-req';