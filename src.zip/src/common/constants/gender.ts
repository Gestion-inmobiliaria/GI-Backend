export enum GENDER {
    MALE = 'masculino',
    FEMALE = 'femenino',
    OTHER = 'otro',
  }