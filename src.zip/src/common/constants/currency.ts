export enum CURRENCY {
    BS = 'bs',
    USD = 'usd',
}