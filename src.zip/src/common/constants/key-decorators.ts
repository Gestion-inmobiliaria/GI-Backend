export const PUBLIC_KEY = 'PUBLIC';
export const ROLES_KEY = 'ROLES';
export const ADMIN_KEY = 'ADMIN';
