export interface IPayload {
  sub: string;
  role: string;  
}
