export { SendMailOptions } from './sendMailOptions.interface';
export { Attachment } from './attachment.interface';