export interface Attachment {
    filename: string;
    path: string;
}