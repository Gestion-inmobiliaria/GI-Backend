export class CreateExampleDto {}
